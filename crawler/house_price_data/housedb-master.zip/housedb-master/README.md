
Housedb 1.0
===========
房产信息网站大数据爬虫。部分数据来源于链家网站（http://www.lianjia.com )，请勿用于商业用途，仅供交流和个人娱乐。

特性
===
- __定期更新房源数据__　
- __提供房源价格变动通知服务__

数据统计
====
- __各个区域的房源数量情况__
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo3.png)
- __各个区域的均价情况__
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo4.png)
- __不同楼龄的房源数量情况__
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo5.png)
- __关注数最高的房源情况__
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo6.png)

房源价格变更
======
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo.PNG)
![](https://raw.githubusercontent.com/coolcooldee/housedb/master/src/main/resources/images/demo2.PNG)
